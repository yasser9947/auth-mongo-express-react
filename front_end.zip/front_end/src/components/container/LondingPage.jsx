import React, { Component } from 'react'

export default class LondingPage extends Component {
    render() {
        return (
            <div>
                <h1>
                    Welcom to Anas Page 
                </h1>
            </div>
        )
    }
}
